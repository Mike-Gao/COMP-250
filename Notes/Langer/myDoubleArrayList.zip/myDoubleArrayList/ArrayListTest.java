package myDoubleArrayList;

public class ArrayListTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyDoubleArrayList  list = new MyDoubleArrayList();
		
		System.out.println("-----test for add( double )-----");
		list.add(1.0);   		list.printList();
		list.add(2.3);		list.printList();
		list.add(3.2);		list.printList();
		list.add(4);		list.printList();
		list.add(5.4);		list.printList();
		list.add(6.32);		list.printList();
		System.out.println("-----test for add( int, double )-----")	;	
		list.add(0, 1.2);		list.printList();
		list.add(-5, 12.7);		list.printList();
		list.add(15, 13.7);		list.printList();
		System.out.println("-----test for remove( int )-----")	;	
		list.remove(-1);		list.printList();
		list.remove(0);		list.printList();
		list.remove(2);		list.printList();
		list.remove(15);		list.printList();
		list.remove(list.size()-1);		list.printList();
		list.remove(list.size());		list.printList();
		System.out.println("-----test for fliprange( int )-----")	;	
		list.flipRange(1,4);		list.printList();
		list.flipRange(1,3);		list.printList();		
		list.flipRange(-10,3);		list.printList();		
		list.flipRange(0,30);		list.printList();
		list.flipRange(0,list.size()-1);		list.printList();
		list.flipRange(0,list.size());		list.printList();
		
		System.out.println("-----test for rotateLeft( int )-----")	;
		list.rotateLeft(2);		list.printList();
		list.rotateLeft(-1);		list.printList();
		list.rotateLeft(-list.size());		list.printList();
		list.rotateLeft(30);			list.printList();
		list.rotateLeft(-30);			list.printList();
	}
}
