package myDoubleArrayList;

/**
 * @author      Michael Langer
 */


public class MyDoubleArrayList {
	private double[]   a;
	private	int		size=0;   //  This is the number of doubles currently in the list.
	                          //  Do not confuse size with the length of the internal array.
	                          //  In particular, it is always the case that size <= a.length

	/**	 Constructor 
	 */
	public MyDoubleArrayList(){
		a = new double[1];
	}
	
	/**	@return  number of elements in the list 
	 */
	
	public int size(){       
		return size;        
	}
	
	/**  Get the element at some position.  
	 *   @param  index  position in list, from 0 to size-1 
	 */
	public double get(int index){
		if ((index >= 0) && (index < size)){
			return a[index];
		}
		else {
			System.out.println("array index out of bounds in method: get(int index)");
			return 0;
		}
	}

	/**  Print out the elements of the list
	 */
	public void printList(){
		System.out.print("[ ");
		for (int j=0; j< size; j++){
			System.out.print(" " + a[j]);
			if (j < size-1)
				System.out.print(",");
		}
		System.out.println(" ] ");
	}
		
	/**  Swap the elements in two given positions of the list.   
	     @param i position in the list, from 0 to size-1
	     @param j position in the list, from 0 to size-1  
	 */
	
	public void swap(int i, int j){
		double tmp;
		if ((i >= 0) && (i < size) && (j >= 0) && (j < size)){
			tmp  = a[i];
			a[i] = a[j];
			a[j] = tmp;
		}
		else
			System.out.println("array index out of bounds in method: swap");
	}

	/**  Add an element to the end of the list.  If the underlying array is 
	 * fully occupied, then it is replaced with one that is twice the length.  
     *
     *	@param x  the element to be added to the list   
	 */  

//  Java's ArrayList increases by 50%. Instead, we will increase the length by 100% for simplicity).
	
	public void add(double x) {
		if (size == a.length){
			double[] b = new double[ 2*a.length ];
			for (int j=0; j < a.length; j++)
				b[j] = a[j];
			a = b;
		}
		a[size] = x;
		size++;
	} 
	
	/**  
	   Insert an element at position index, where index is a existing position within the list so  0 <=  index < size.   
	 */
	
	public void add(int index, double x) {

		//  Check for array bounds
		if ((index >= 0) && (index < size)){
			add(x);           		// increases size by 1
			swap(index,size-1);     
		}
		else
			System.out.println("array index out of bounds in method: add(int, double)");
	}
	
	/**   Remove an element from the list.   
	 *    @return  the removed element
	 */
	
	public double remove(int index){
		double tmp;
		if ((index >= 0) && (index < size)){
			tmp = a[index];
			for (int j=index; j < size; j++)
				a[j] = a[j+1];
			size--;
			return tmp;
		}
		else {
			System.out.println("array index out of bounds in method: remove(int index)");
			return 0;
		}
	}
	
	/**
	 *    Reverse the order of the elements in some index range [low, high]
	 *    where 0 <= low <= high < size.   
	 * 	  @param  low  where the range starts 
	 * 	  @param  high where the range ends   
	 */
	
	public void flipRange(int low, int high){
		if ((0 <= low) && (low < high) && (high < size)){
			for (int k = low; k <= (low + high)/2; k++)
				swap(k, high-(k-low));		
		}
		else if ((low < 0) || (high >= size))
			System.out.println("index out of bounds: flipRange(int low , int high)");
	}	
	

	/*  rotateLeft shifts the elements in the array to the left by i positions.   
	 *  Elements at starting positions less than i should be shifted to
	 *  the back of the array, as if the array were a circle.  For example,
	 *  rotating left by 1 would move element at a[1] to a[0], and it would
	 *  move element at a[0] to a[ size-1 ].   Rotating left by i should have
	 *  the same result as rotating left by 1, repeated i times.
	 *  
	 *  A more efficient way to implement this method is to do the following.   
	 *  
	 *  		flipRange(0,distance-1);
	 * 			flipRange(distance,size-1);
     *			flipRange(0,size-1);
     *
     *   This works provided that 0 < distance <= size -1 but will generate
     *   an error in other cases.   Modify this method so that it computes 
     *   the correct result for any int shift distance.
     *   Note that 'distance < 0' means rotating right rather than left. 
	 */

	
/**
 *   Shift each element left by a given distance.   Elements that move past position 0 wrap around.   
 *   For example, if the element at position 0 moves left, then it moves to position size-1.  
 *   If distance is negative, then the elements move right instead.
 *    @param  distance the number of positions to shift left
 */
	
	public void rotateLeft(int distance){
		int distanceModLength = distance;
		while (distanceModLength < 0)
		   distanceModLength += size;
		while (distanceModLength >= size)
			   distanceModLength -= size;
		flipRange(0,distanceModLength-1);
		flipRange(distanceModLength,size-1);
		flipRange(0,size-1);
	}	
}
